<?php
// Text
$_['text_search']                             = 'Search';
$_['text_blog'] = 'Blog';
