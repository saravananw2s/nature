<?php
// Heading 
$_['heading_title'] = 'categories';

// Text
$_['text_more_vertical_menu'] = '<i class="fa fa-plus"></i>More Categories';
$_['text_close_vertical_menu'] = '<i class="fa fa-minus"></i>Close Menu';