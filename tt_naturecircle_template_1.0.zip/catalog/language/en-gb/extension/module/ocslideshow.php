<?php
$_['text_readmore'] = 'shop now';