<?php
// Text
$_['text_items']     = '%s';
$_['text_items2']     = 'item(s)';
$_['total_price']     = '%s';

$_['text_shoppingcart']     = 'Shopping Cart';
$_['text_empty']     = 'Your shopping cart is empty!';
$_['text_cart']      = 'View Cart';
$_['text_checkout']  = 'Checkout';
$_['text_recurring'] = 'Payment Profile';